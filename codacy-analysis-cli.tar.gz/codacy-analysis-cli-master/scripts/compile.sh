#!/usr/bin/env bash

set -e

sbt +test:compile
