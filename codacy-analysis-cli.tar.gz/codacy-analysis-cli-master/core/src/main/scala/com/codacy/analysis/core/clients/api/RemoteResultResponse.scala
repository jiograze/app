package com.codacy.analysis.core.clients.api

final case class RemoteResultResponse(success: String)
