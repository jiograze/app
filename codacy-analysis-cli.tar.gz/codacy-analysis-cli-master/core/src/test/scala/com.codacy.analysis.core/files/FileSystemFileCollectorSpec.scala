package com.codacy.analysis.core.files

class FileSystemFileCollectorSpec extends FileCollectorSpec(new FileSystemFileCollector())
