package com.codacy.analysis.core.model

case class ParameterSpec(name: String, default: String, description: Option[String])
